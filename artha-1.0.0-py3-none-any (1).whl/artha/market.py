"""Session generation: volume, price, mandate and the liquidity shock.

Volume is generated, never bootstrapped -- that is the leak defence. Price is a
block bootstrap of rotated real returns, in blocks that never span an overnight
boundary.
"""

from __future__ import annotations

import dataclasses

import numpy as np

from . import config as C


def intraday_profile(n_bars: int = C.N_BARS) -> np.ndarray:
    """Mean intraday volume shape, measured from the real corpus."""
    shape = np.array([12.8, 6.7, 5.2, 4.3, 4.0, 3.5, 3.1, 3.0, 3.0, 2.8, 2.6, 2.6,
                      2.8, 2.9, 2.6, 2.5, 2.7, 2.9, 2.9, 3.2, 3.2, 3.5, 3.8, 5.7, 7.8])
    p = np.interp(np.linspace(0, len(shape) - 1, n_bars), np.arange(len(shape)), shape)
    return p / p.sum()


PROFILE = intraday_profile()


@dataclasses.dataclass(frozen=True)
class Session:
    """One evaluation path. Everything an agent may see, and the counterfactual
    ground truth it may not."""

    instruments: tuple[str, ...]
    base: dict[str, np.ndarray]        # midpoint with nobody trading
    volume: dict[str, np.ndarray]      # bar volume
    sigma_bar: dict[str, np.ndarray]   # per-bar volatility, bps
    mandate: dict[str, float]          # signed: + buy, - sell
    shock_at: int | None
    path_id: str

    @property
    def n_bars(self) -> int:
        return len(self.base[self.instruments[0]])

    def sigma_session(self, sym: str) -> float:
        return float(self.sigma_bar[sym].mean() * np.sqrt(self.n_bars))

    def notional(self, sym: str) -> float:
        return abs(self.mandate[sym]) * float(self.base[sym][0])


VOL_COMMON = 0.6   # market-wide share of an instrument's volume variation


def _volume_path(rng, n_bars, profile, common_scale=0.0, common_dev=None):
    """Intraday profile x session-level lognormal scale x AR(1) log deviations,
    each part split between a market-wide component and an idiosyncratic one."""
    own_scale = rng.normal(0, C.VOL_SESSION_SIGMA)
    scale = np.exp(VOL_COMMON * common_scale + (1 - VOL_COMMON) * own_scale)

    own = np.zeros(n_bars)
    for t in range(1, n_bars):
        own[t] = C.VOL_AR_RHO * own[t - 1] + rng.normal(0, C.VOL_AR_SIGMA)
    dev = VOL_COMMON * (common_dev if common_dev is not None else 0.0) \
        + (1 - VOL_COMMON) * own

    v = profile * 1_000_000.0 * scale * np.exp(dev - np.var(dev) / 2)
    return np.maximum(v, 1.0)


def generate_session(
    rng: np.random.Generator,
    blocks: dict[str, np.ndarray] | None = None,
    instruments: tuple[str, ...] | None = None,
    n_bars: int = C.N_BARS,
    path_id: str = "local",
    mandate_frac: tuple[float, float] | None = None,
) -> Session:
    """Build one session.

    `blocks` maps instrument -> (n_blocks, BLOCK_BARS) array of rotated real
    returns. When absent, returns are drawn parametrically so the tutorial
    sandbox and the test suite can run without the corpus.
    """
    instruments = instruments or C.INSTRUMENTS
    mandate_frac = mandate_frac or C.MANDATE_FRAC
    profile = intraday_profile(n_bars)

    shock_at = None
    if rng.random() < C.SHOCK_PROB:
        lo, hi = C.SHOCK_WINDOW
        shock_at = int(rng.integers(int(lo * n_bars), int(hi * n_bars)))
        depth = rng.uniform(*C.SHOCK_DEPTH)

    base, volume, sigma_bar, mandate = {}, {}, {}, {}
    # Every path is renormalised to an arbitrary price level so no instrument can
    # be recognised by where it trades.
    level = float(rng.uniform(60.0, 400.0))

    # Shared across instruments: block i is contemporaneous in every leg, which
    # is what preserves the correlation they were minted with.
    shared_pick = None
    if blocks is not None:
        lib0 = blocks[instruments[0]]
        n_blk = int(np.ceil(n_bars / lib0.shape[1]))
        shared_pick = rng.integers(0, lib0.shape[0], n_blk)

    # A busy session is busy in everything, so volume shares a market-wide component.
    common_scale = rng.normal(0, C.VOL_SESSION_SIGMA)
    common_dev = np.zeros(n_bars)
    for t in range(1, n_bars):
        common_dev[t] = C.VOL_AR_RHO * common_dev[t - 1] + rng.normal(0, C.VOL_AR_SIGMA)

    # Nothing observable before the shock may depend on it, so every ex-ante
    # quantity is computed from the unshocked path.
    ex_ante_volume = {}
    for sym in instruments:
        v_clean = _volume_path(rng, n_bars, profile, common_scale, common_dev)
        ex_ante_volume[sym] = v_clean

        # Reference stats come from the unshocked path, so bar t's volatility
        # cannot encode a collapse at bar t+k.
        lv = np.log(v_clean)
        sig = 4.9 * (1.0 + C.VOL_PRICE_COUPLING * (lv - lv.mean()) / max(lv.std(), 1e-9))
        sig = np.clip(sig, 1.0, None)

        v = v_clean.copy()
        if shock_at is not None:
            v[shock_at:] *= depth
            sig[shock_at:] *= 1.35        # applied to the FUTURE only

        if blocks is not None and sym in blocks:
            lib = blocks[sym]
            r = np.concatenate([lib[i] for i in shared_pick])[:n_bars]
            r = r / max(r.std(), 1e-12) * (sig / 1e4)
        else:
            r = rng.normal(0, sig / 1e4, n_bars)

        base[sym] = level * np.exp(np.cumsum(r))
        volume[sym] = v
        sigma_bar[sym] = sig

    # Legs are sized to equal notional at arrival, so proportional execution
    # carries no net exposure and racing one leg ahead of another does.
    frac = rng.uniform(*mandate_frac)
    lead = instruments[0]
    # Ex-ante liquidity: sizing off realised volume would let the mandate
    # announce the shock.
    target_notional = frac * float(ex_ante_volume[lead].sum()) * float(base[lead][0])
    signs = _mandate_signs(rng, instruments)
    # All instruments are quoted; the mandate covers a subset and is zero
    # elsewhere, so a bot must read it rather than assume its shape.
    for sym in instruments:
        mandate[sym] = signs.get(sym, 0) * target_notional / float(base[sym][0])

    return Session(
        instruments=tuple(instruments), base=base, volume=volume,
        sigma_bar=sigma_bar, mandate=mandate, shock_at=shock_at, path_id=path_id,
    )


def _mandate_signs(rng, instruments) -> dict[str, int]:
    """Two legs opposed, and a third on roughly a third of paths."""
    a, b, c = instruments
    legs = {a: 1, b: -1}
    if rng.random() < 0.34:
        legs[c] = int(rng.choice([1, -1]))
    if rng.random() < 0.5:                      # flip the whole mandate
        legs = {k: -v for k, v in legs.items()}
    return legs
