"""Canonical score weights.

Derived from a fixed reference field, never from the submission being scored:
w = m/sigma calibrated per-submission is an exploit, since a bot that makes a
component erratic shrinks that component's own weight.
"""

from __future__ import annotations

import json
import pathlib

import numpy as np

from . import config as C

CACHE = pathlib.Path(__file__).parent / "weights.json"


def calibrate(n_paths: int = 300, seed: int = 20260823, basis: str | None = None) -> dict:
    """Run the reference field and derive the canonical weights from it."""
    from .bots import build_reference_field
    from .engine import run_session
    from .market import generate_session
    from .score import decompose

    basis = basis or C.WEIGHT_BASIS
    rng = np.random.default_rng(seed)
    per_bot = {}
    for i in range(n_paths):
        session = generate_session(rng, path_id=f"cal{i:05d}")
        agents = build_reference_field()
        res = run_session(session, agents)
        for name in agents:
            c = decompose(session, res[name]["schedule"], res["_field"])
            c.pop("legs")
            per_bot.setdefault(name, []).append(c)

    # sigma_k must be MEASUREMENT noise -- how precisely one team's mean is
    # known -- not the spread between different strategies. Pooling all bots
    # conflates the two: the reference field spans impact costs from 9 to 246
    # bps, which inflates sigma_impact to ~93 and drives its weight to 0.03,
    # handing the competition to whichever term happens to be most uniform.
    # So take each bot's own across-path sigma and use the median.
    sigmas, means = {}, {}
    for k in C.SCORED_TERMS:
        within = [np.std([r[k] for r in rows], ddof=1) for rows in per_bot.values()]
        sigmas[k] = float(np.median(within))
        means[k] = float(np.mean([r[k] for rows in per_bot.values() for r in rows]))

    w = {}
    for k in C.SCORED_TERMS:
        sd = sigmas[k]
        if basis == "sem":
            # Standard error of a team's mean over the evaluation set. Field
            # composition noise averages out across paths, so crowding keeps the
            # weight its role in the finale deserves.
            sd = sd / np.sqrt(C.SPLITS["private"][2])
        w[k] = C.EMPHASIS[k] / max(sd, 1e-9)
    total = sum(w.values())
    w = {k: v / total for k, v in w.items()}

    payload = {"weights": w, "basis": basis, "n_paths": n_paths, "seed": seed,
               "means": means, "sigmas": sigmas}
    CACHE.write_text(json.dumps(payload, indent=2))
    return payload


def load() -> dict:
    """Canonical weights, calibrating on first use if the cache is absent."""
    if not CACHE.exists():
        calibrate()
    return json.loads(CACHE.read_text())["weights"]
