"""Execution engine. One code path runs a lone bot and the full finale field.

In lockstep every agent sees the bar before any of them acts, all orders are
collected, and only then is the combined flow applied -- so iteration order
cannot matter and no bot can react to a rival within a bar.
"""

from __future__ import annotations

import dataclasses

import numpy as np

from . import config as C


@dataclasses.dataclass
class BarState:
    """Everything an agent may see at bar t. Nothing here reveals the future."""

    bar: int
    n_bars: int
    instruments: tuple[str, ...]
    mandate: dict[str, float]          # signed target, fixed for the session
    remaining: dict[str, float]        # signed, still to execute
    mid: dict[str, float]              # current observed midpoint
    last_volume: dict[str, float]      # volume printed in bar t-1
    volume_history: dict[str, list]    # all volume up to t-1
    mid_history: dict[str, list]       # all observed mids up to t

    @property
    def bars_left(self) -> int:
        return self.n_bars - self.bar


class Rejection(Exception):
    pass


def _validate(order, state, sym):
    """An order must move toward the mandate and never past it."""
    q = float(order)
    if not np.isfinite(q):
        raise Rejection(f"{sym}: non-finite quantity")
    rem = state.remaining[sym]
    if q == 0.0:
        return 0.0
    if np.sign(q) != np.sign(rem) and rem != 0.0:
        raise Rejection(f"{sym}: wrong side (remaining {rem:+.0f}, ordered {q:+.0f})")
    if abs(q) > abs(rem) + 1e-6:
        raise Rejection(f"{sym}: overfill (remaining {rem:+.0f}, ordered {q:+.0f})")
    return q


def run_session(session, agents: dict, mandates: dict | None = None,
                max_rejections: int = 5) -> dict:
    """Step every agent through the session in lockstep.

    mandates: {agent: {sym: signed qty}}, defaulting to the session mandate.
    Half the field must be given the opposite side: with one-way flow the field's
    permanent impact is a predictable drift, front-running it becomes a dominant
    strategy, and the equilibrium collapses to universal aggression.

    Returns {agent: {"schedule", "rejections", "disqualified", "mandate"}} plus
    "_field" with the combined net and gross flow.
    """
    n = session.n_bars
    syms = session.instruments
    mandates = mandates or {a: dict(session.mandate) for a in agents}

    filled = {a: {s: np.zeros(n) for s in syms} for a in agents}
    rejections = {a: [] for a in agents}
    dq = {a: False for a in agents}
    net = {s: np.zeros(n) for s in syms}
    gross = {s: np.zeros(n) for s in syms}
    hist_v = {s: [] for s in syms}
    hist_m = {s: [] for s in syms}
    cum_g = {s: 0.0 for s in syms}

    for t in range(n):
        # Observed midpoint carries the permanent impact of everything traded so
        # far -- agents act on the market they have already moved.
        mid = {s: float(session.base[s][t] * np.exp(cum_g[s])) for s in syms}
        for s in syms:
            hist_m[s].append(mid[s])

        orders = {}
        for name, bot in agents.items():
            if dq[name]:
                orders[name] = {s: 0.0 for s in syms}
                continue
            remaining = {s: mandates[name][s] - filled[name][s].sum() for s in syms}
            state = BarState(
                bar=t, n_bars=n, instruments=syms,
                mandate=dict(mandates[name]), remaining=remaining, mid=mid,
                last_volume={s: (hist_v[s][-1] if hist_v[s] else 0.0) for s in syms},
                volume_history={s: list(hist_v[s]) for s in syms},
                mid_history={s: list(hist_m[s]) for s in syms},
            )
            try:
                raw = bot.on_bar(state) or {}
            except Exception as exc:                      # a crash is a no-trade bar
                rejections[name].append((t, f"raised {type(exc).__name__}: {exc}"))
                raw = {}

            clean = {}
            for s in syms:
                try:
                    q = _validate(raw.get(s, 0.0), state, s)
                except Rejection as exc:
                    rejections[name].append((t, str(exc)))
                    q = 0.0
                # The final bar is the closing auction: exempt, but square-root
                # impact prices it steeply enough to be self-limiting.
                is_close = C.CLOSING_AUCTION and t == n - 1
                if not is_close:
                    cap = C.MAX_PARTICIPATION * session.volume[s][t]
                    if abs(q) > cap:
                        q = np.sign(q) * cap
                clean[s] = q
            orders[name] = clean
            if len(rejections[name]) > max_rejections:
                dq[name] = True

        for name, o in orders.items():
            for s in syms:
                filled[name][s][t] = o[s]
                net[s][t] += o[s]
                gross[s][t] += abs(o[s])

        for s in syms:
            g = (C.K_PERM * net[s][t] / session.volume[s].sum()
                 * session.sigma_session(s) / 1e4)
            cum_g[s] += g
            hist_v[s].append(float(session.volume[s][t]))

    out = {a: {"schedule": filled[a], "rejections": rejections[a],
               "disqualified": dq[a], "mandate": mandates[a]} for a in agents}
    out["_field"] = {"net": net, "gross": gross}
    return out
