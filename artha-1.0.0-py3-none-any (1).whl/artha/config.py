"""Competition constants.

Several are coupled and must not be tuned independently. tests/test_acceptance.py
fails if any drifts out of its working range.
"""

from __future__ import annotations

import os as _os

# ------------------------------------------------------------------ session

N_BARS = 320                                   # not 375: that length identifies the exchange
INSTRUMENTS = ("ASHVAM", "BRIHAT", "CHAKRA")

# ------------------------------------------------------------------ impact

K_TEMP = 11.0          # per bar, against bar volume
K_PERM = 4.0           # per session, against session volume

MAX_PARTICIPATION = 0.25
"""Per-bar cap, clipped in the engine. Coupled to MANDATE_FRAC: the cap must sit
several times above the participation a well-paced bot needs, or it clips honest
schedules instead of dishonest ones."""

CLOSING_AUCTION = True                         # final bar exempt from the cap
RISK_AVERSION = 0.35                           # lambda on exposure and carry

PENALTY_BPS = 200.0
"""Flat charge on any residual, on top of the residual's own force-fill impact.
Coupled to K_TEMP/K_PERM: raise the impact coefficients and under-filling becomes
profitable again."""

# ------------------------------------------------------------------ volume

VOL_AR_RHO = 0.85
VOL_AR_SIGMA = 0.30
VOL_SESSION_SIGMA = 0.35
VOL_PRICE_COUPLING = 0.25                      # do not raise: caps the price->volume leak

SHOCK_PROB = 0.40
SHOCK_WINDOW = (0.35, 0.75)
SHOCK_DEPTH = (0.25, 0.40)

# ------------------------------------------------------------------ scoring

SCORED_TERMS = ("impact", "crowding", "exposure", "carry")
WEIGHTS = {"impact": 1.0, "crowding": 1.0, "exposure": 1.0, "carry": 1.0}
"""Every term is basis points of the same notional, so the score is their sum.
Inverse-sigma weighting was tried and abandoned: it is exploitable, because a bot
that makes a component erratic shrinks that component's own weight."""

# 'timing' is reported but never scored: its mean is ~0 for every schedule.

# ------------------------------------------------------------------ splits

SPLITS = {
    "train":   ("2025-01-01", "2025-10-31", 400),
    "public":  ("2025-11-01", "2026-02-28", 120),
    "private": ("2026-03-01", "2026-06-16", 200),
}
"""Disjoint at the SOURCE BAR, not merely at the path, so overfitting the public
board cannot transfer to the private one."""

MANDATE_FRAC = (0.03, 0.07)                    # of ex-ante session volume
BLOCK_BARS = 80                                # blocks never span an overnight boundary

# ------------------------------------------------------------------ limits

MAX_SUBMISSIONS_PER_DAY = int(_os.environ.get("ARTHA_DAILY_LIMIT", 20))
PUBLIC_COOLDOWN_S = int(_os.environ.get("ARTHA_COOLDOWN", 600))
COMPETITION_TZ = "Asia/Kolkata"

BAR_TIMEOUT_S = float(_os.environ.get("ARTHA_BAR_TIMEOUT", 2.0))
"""Per-bar deadline for a bot. Documented in RULES.md from this value."""
