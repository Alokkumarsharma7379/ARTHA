"""Scoring: one shortfall, decomposed against three counterfactual price paths.

    m0      nobody trades
    m_solo  only this agent trades
    m_field everyone trades

    timing   = C_frictionless - C_arrival      drift while exposed
    impact   = C_solo         - C_frictionless own footprint
    crowding = C_actual       - C_solo         the field's footprint on you

Those three sum to implementation shortfall. `timing` is reported but not scored:
its mean is zero for every schedule, so ranking on it ranks on luck. Schedule risk
is charged deterministically instead, as `exposure` and `carry`.
"""

from __future__ import annotations

import numpy as np

from . import config as C
from .impact import fill_prices

EPS_NOTIONAL = 1e-6   # floor on any notional denominator, so a NaN cannot reach a leaderboard


def decompose(session, schedule, field_flow=None, mandate=None) -> dict[str, float]:
    """Score components in bps of mandate notional, for one agent.

    schedule:   {sym: array(n_bars)} signed quantities the agent actually traded
    field_flow: {"net": {sym: array}, "gross": {sym: array}} for the WHOLE field
                including this agent. None means the agent traded alone.
    """
    n = session.n_bars
    mandate = mandate or session.mandate
    legs, total_notional = {}, 0.0

    for sym in session.instruments:
        Q = mandate[sym]
        if Q == 0.0:               # quoted but not mandated on this path
            continue
        q = np.asarray(schedule.get(sym, np.zeros(n)), float)
        base = session.base[sym]
        vol = session.volume[sym]
        sig_bar = session.sigma_bar[sym]
        sig_ses = session.sigma_session(sym)
        # Anything unplaced is force-filled into the closing auction, charged
        # its own impact there, with the flat penalty on top.
        residual = Q - q.sum()
        q_eff = q
        if abs(residual) > 1e-9:
            q_eff = q.copy()
            q_eff[-1] += residual

        if field_flow is None:
            f_net, f_gross = q_eff, np.abs(q_eff)
        else:
            f_net = np.asarray(field_flow["net"][sym], float).copy()
            f_gross = np.asarray(field_flow["gross"][sym], float).copy()
            f_net[-1] += residual
            f_gross[-1] += abs(residual)

        p_solo, _ = fill_prices(base, q_eff, np.abs(q_eff), q_eff, vol, sig_bar, sig_ses)
        p_field, _ = fill_prices(base, f_net, f_gross, q_eff, vol, sig_bar, sig_ses)

        notional = max(abs(Q) * float(base[0]), EPS_NOTIONAL)
        c_arrival = Q * float(base[0])
        c_frict = float((q_eff * base).sum())
        c_solo = float((q_eff * p_solo).sum())
        c_actual = float((q_eff * p_field).sum())
        penalty = abs(residual) * float(base[-1]) * C.PENALTY_BPS / 1e4

        remaining = (Q - np.cumsum(q)) / Q if Q != 0 else np.zeros(n)
        exposure = C.RISK_AVERSION * sig_ses * float(np.sqrt(np.mean(remaining ** 2)))

        legs[sym] = dict(
            timing=(c_frict - c_arrival) / notional * 1e4,
            impact=(c_solo - c_frict) / notional * 1e4,
            crowding=(c_actual - c_solo) / notional * 1e4,
            exposure=exposure,
            penalty=penalty / notional * 1e4,
            filled=float(q.sum() / Q) if Q != 0 else 1.0,   # what the BOT placed
        )
        total_notional += notional

    out = {k: 0.0 for k in ("timing", "impact", "crowding", "exposure", "penalty")}
    for sym, d in legs.items():
        w = (abs(mandate[sym]) * float(session.base[sym][0])) / total_notional
        for k in out:
            out[k] += w * d[k]

    out["carry"] = _carry(session, schedule, mandate)
    out["shortfall"] = out["timing"] + out["impact"] + out["crowding"]
    out["filled"] = min(d["filled"] for d in legs.values())
    out["legs"] = legs
    return out


def _carry(session, schedule, mandate=None) -> float:
    """Risk from the legs being out of step: an unhedged position the mandate
    never asked for, charged as variance rather than realised cost."""
    n = session.n_bars
    mandate = mandate or session.mandate
    net = np.zeros(n)
    notional = 0.0
    sig = 0.0
    for sym in session.instruments:
        if mandate[sym] == 0.0:
            continue
        q = np.asarray(schedule.get(sym, np.zeros(n)), float)
        p0 = float(session.base[sym][0])
        net += np.cumsum(q) * p0
        notional += abs(mandate[sym]) * p0
        sig = max(sig, session.sigma_session(sym))
    return C.RISK_AVERSION * sig * float(
        np.sqrt(np.mean((net / max(notional, EPS_NOTIONAL)) ** 2)))


# ---------------------------------------------------------------- weights

def combine(components: dict[str, float], weights: dict | None = None) -> float:
    """Final score in bps. Lower is better.

    Penalty is added at full weight -- it is not a skill term, it is a rule
    violation."""
    w = weights or C.WEIGHTS
    s = sum(w[k] * components[k] for k in C.SCORED_TERMS)
    return s + components.get("penalty", 0.0)
